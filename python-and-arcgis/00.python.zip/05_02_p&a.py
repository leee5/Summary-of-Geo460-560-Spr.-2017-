# Some of the built-in functions we have seen require arguments.

# to use math functions
import math
# math.sqrt(2)

# Some functions take more than one argument.
# math.pow(3, 4)

# Inside the function,
# the arguments are assigned to variables called parameters.

def print_twice(bruce):
    print bruce
    print bruce

print_twice('Spam')
print_twice(17)
print_twice(math.pi)
print_twice('Spam ' * 4)
print_twice(math.cos(math.pi))
