print("Number\tSquare")
print("--------------")

for number in range(1, 11):
    square = number ** 2
    print(str(number) + "\t" + str(square))
