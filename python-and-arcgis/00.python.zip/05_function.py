# A function is a group of statements
# that exist within a program for the purpose of performing a specific task.
# Instead of writing a large program as one long sequence of statements,
# it can be written as several small functions,
# each one performing a specific part of the task.
# These small functions can then be executed
# in the desired order to perform the overall task.

###################################################
# Benefits of Modularizing a Program with Functions

# simpler code
# code reuse
# better testing
# faster development
# easier facilitation of teamwork
###################################################

# Defining a Function
# def function_name():
#   statement
#   statement
#   etc.

# Calling a Function
# theFunction()

def message():
    print("I am Arthur, ")
    print("King of the Britons.")

message()


# 05_function2.py
# 05_01_printLyrics.py
# 05_02_p&a.py
