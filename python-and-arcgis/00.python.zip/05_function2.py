# two functions

# define the main function
def main():
    print("I have a message for you.")
    message()
    print("Goodbye.")
    
# define the message function
def message():
    print("I am Arthur, ")
    print("King of the Britons.")

# call the main function
main()
