# The if statement is used to create a decision structure,
# which allows a program to have more than one path of execution.

# general format of the if statement
# if condition_1:
#   statement
#   statement
#   etc.
# elif condition_2:
#   statement
#   statement
#   etc.
##############################################
# insert as many elif clauses as necessary ...
##############################################
# else:
#   statement
#   statement
#   etc.

# Boolean expressions using relational operators
# Expression    Meaning
# x > y         Is x greater than y?
# x < y         Is x less than y?
# x >= y        Is x greater than or equal to y?
# x <= y        Is x less than or equal to y?
# x == y        Is x equal to y?
# x != y        Is x not equal to y?

# 04_01_testAverage.py
# 04_02_autoRepairPayroll.py
# 04_03_letter2num.py
# 04_03_sortNames.py
# 04_04_grader.py
# 04_04_grader2.py

# You use the for statement to write a count-controlled loop.
# In Python, the for statement is designed
# to work with a sequence of data items.
# When the statement executes, it iterates once for each itemin the sequence.
# Here is the general format:
# for variable in [value1, value2, etc.]:
#   statement
#   statement
#   etc.

# 04_05_simpleFor.py
# 04_05_simpleFor2.py
# 04_05_simpleForRange.py
# 04_05_squares.py
