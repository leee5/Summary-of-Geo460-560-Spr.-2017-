# In the 2.x series, print is a statement, while in 3.x it's a function.
# If you want in 2.6+ to have print as a function,
# you use from __future__ import print_function as the first import statement.
from __future__ import print_function

# global constants
BASE_HOURS = 40 # base hours per week
OT_MULTIPLIER = 1.5 # overtime multiplier

# main function gets the number of hours worked & the hourly pay rate
# calles either calc_pay_with_OT or calc_regular_pay
# to calculate & display the gross pay
def main():
    # get the hours worked & the hourly pay rate
    hours_worked = float(input("Enter the number of hours worked: "))
    pay_rate = float(input("Enter the hourly pay rate: "))

    # calculate & display the gross pay
    if hours_worked > BASE_HOURS:
        calc_pay_with_OT(hours_worked, pay_rate)
    else:
        calc_regular_pay(hours_worked, pay_rate)

# calc_pay_with_OT function: calculate pay with overtime
# it accepts the hours worked & the hourly pay rate as arguments
def calc_pay_with_OT(hours, rate):
    # calculate the number of overtime hours worked
    overtime_hours = hours - BASE_HOURS
    # calculate the amount of overtime pay
    overtime_pay = overtime_hours * rate * OT_MULTIPLIER
    # calcuate the gross pay
    gross_pay = BASE_HOURS * rate + overtime_pay
    # display the gross pay
    print("The gross pay is $", format(gross_pay, ",.2f"), sep = "")

# calc_regular_pay function: calculate pay with no overtime
# it accepts the hours worked & the hourly pay rate as arguments
def calc_regular_pay(hours, rate):
    # calculate the gross pay
    gross_pay = hours * rate
    # display the gross pay
    print("The gross pay is $", format(gross_pay, ",.2f"), sep = "")

# call the main function
main()
    
    
