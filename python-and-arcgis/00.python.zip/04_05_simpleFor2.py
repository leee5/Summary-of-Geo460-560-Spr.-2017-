squares = [1, 4, 9, 16]
sum = 0

#for num in squares:
#    sum += num
#    print sum

for num in squares:
    sum = sum + num
    print sum
