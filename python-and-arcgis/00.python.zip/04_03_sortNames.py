# compare strings with the < operator
name1 = input("Enter a name (last name first): ")
name2 = input("Enter another name (last name first): ")

# display the names in alphabetical order
print("Here are the names, listed alphabetically.")

if name1 < name2:
    print(name1)
    print(name2)
else:
    print(name2)
    print(name1)

#################################
# chr(97)
# ord('a')
# ord('A')
# ord('z')
# ord('Z')
# http://www.asciitable.com/
#################################
