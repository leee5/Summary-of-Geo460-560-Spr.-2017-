# https://docs.python.org/2/tutorial/introduction.html
# https://developers.google.com/edu/python/lists

# Python knows a number of compound data types,
# used to group together other values.
# The most versatile is the list,
# which can be written as a list of comma-separated values (items)
# between square brackets. 
# Lists might contain items of different types,
# but usually the items all have the same type.

# List literals are written within square brackets [ ].
# Lists work similarly to strings --
# use the len() function and square brackets [ ] to access data,
# with the first element at index 0.

squares = [1, 4, 9, 16, 25]
squares
squares[0]
squares[-1]
squares[-3:]
squares[:]

# lists also supports operations like concatenation
squares + [36, 49, 64, 81, 100]

# unlike strings, which are immutable, lists are a mutable type,
# i.e. it is possible to change their content
word = 'Python'
word[0] = 'J' # TypeError: 'str' object does not support item assignment

cubes = [1, 8, 27, 65, 125] # something's wrong here
4 ** 3 # the cube of 4 is 64, not 65
cubes[3] = 64 # replace the wrong value
cubes

# you can also add new items at the end of the list, by using the append() method
cubes.append(216)
cubes.append(7 ** 3)
cubes

# assignment to slices is also possible
letters = ['a', 'b', 'c', 'd', 'e' 'f', 'g']
letters
letters[2:5] = ['C', 'D', 'E']
letters
letters[2:5] = []
letters
letters[:] = []
letters

letters = ['a', 'b', 'c', 'd']
len(letters)

# it is possible to nest lists (create lists containing other lists)
a = ['a', 'b', 'c']
n = [1, 2, 3]
x = [a, n]
x
x[0]
x[0][1]

# list methods more
list = ['larry', 'curly', 'moe']
list.append('shemp')  # append elem at end
list.insert(0, 'xxx') # insert elem at index 0
list.extend(['yyy', 'zzz']) # add list of elems at end
print list
print list.index('curly')

list.remove('curly') # remove the elem
list.pop(1) # removes and returns the elem at index
print list

list = [1, 2, 3]
print list.append(4) # None - the above methods do not return the modified list
list.append(4)
print list # [1, 2, 3, 4, 4]

# list build up
list = []
list.append('a')
list.append('b')

# list slices
list = ['a', 'b', 'c', 'd']
print list[1:-1]
list[0:2] = 'z' # replace ['a', 'b'] with ['z']
print list
