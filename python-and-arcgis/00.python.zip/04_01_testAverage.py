HIGH_SCORE = 95

test1 = int(input("Enter the score for test 1: "))
test2 = int(input("Enter the score for test 2: "))
test3 = int(input("Enter the score for test 3: "))

# calculate the average
average = (test1 + test2 + test3) / 3
print("The average score is: " + str(average))

# congatulate the person if ...
if average >= HIGH_SCORE:
    print("Congratulations!")
    print("That is a greate average!")
