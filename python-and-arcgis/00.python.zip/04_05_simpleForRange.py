# for num in range(5):
#    print num

# for num in [0, 1, 2, 3, 4]:
#    print num

# for x in range(5):
#    print('Hi, Mookie!')

# for num in range(1, 5):
#    print num

for num in range(1, 10, 2):
    print num
